<div class="copyrights">
	 <p>© 2022 TRIPPYGO Created by Sumukh K J,M Chandan,Rakshitha G,Vinayak Katti. All Rights Reserved |  <a href="http://localhost/trippygo/index.php">TRIPPYGO</a> </p>
</div>
